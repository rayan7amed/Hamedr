﻿using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace SE2___Lab1
{
    class Program
    {
        static void Main(string[] args)
        {

        }
    }

}
